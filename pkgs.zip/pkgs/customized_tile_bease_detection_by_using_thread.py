import cv2
import torch
import time
import numpy as np
import os
import glob
import threading
from queue import Queue
from numpy import random
from models.experimental import attempt_load
from utils.general import check_img_size, non_max_suppression, scale_coords
from utils.plots import plot_one_box
from utils.torch_utils import select_device, time_synchronized, TracedModel


def split_image_into_tiles(image, tile_size=640):
    tiles = []
    positions = []
    horizontal_overlap = 280
    vertical_overlap = 32
    h, w = image.shape[:2]
    for y in range(0, h - horizontal_overlap, tile_size - horizontal_overlap):
        for x in range(0, w - vertical_overlap, tile_size - vertical_overlap):
            tile = image[y:y + tile_size, x:x + tile_size]
            if tile.shape[0] == tile_size and tile.shape[1] == tile_size:
                tiles.append(tile)
                positions.append((x, y))
    return tiles, positions


def letterbox(img, new_shape=(640, 640), color=(114, 114, 114), auto=True,
              scaleFill=False, scaleup=True, stride=32):
    shape = img.shape[:2]  # current shape [height, width]
    if isinstance(new_shape, int):
        new_shape = (new_shape, new_shape)
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    if not scaleup:
        r = min(r, 1.0)
    ratio = r, r  # width, height ratios
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]
    if auto:
        dw, dh = np.mod(dw, stride), np.mod(dh, stride)
    elif scaleFill:
        dw, dh = 0.0, 0.0
        new_unpad = (new_shape[1], new_shape[0])
        ratio = new_shape[1] / shape[1], new_shape[0] / shape[0]
    dw /= 2
    dh /= 2

    if shape[::-1] != new_unpad:
        img = cv2.resize(img, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    img = cv2.copyMakeBorder(img, top, bottom, left, right,
                             cv2.BORDER_CONSTANT, value=color)
    return img, ratio, (dw, dh)


def detect_tile(model, tile, tile_pos, device, img_size, stride, half, conf_thres, iou_thres, results_queue):
    im0 = tile.copy()
    img, ratio, (dw, dh) = letterbox(im0, new_shape=img_size, stride=stride)
    img = img[:, :, ::-1].transpose(2, 0, 1)  # BGR to RGB
    img = np.ascontiguousarray(img)

    img = torch.from_numpy(img).to(device)
    img = img.half() if half else img.float()
    img /= 255.0
    if img.ndimension() == 3:
        img = img.unsqueeze(0)

    with torch.no_grad():
        pred = model(img)[0]
        pred = non_max_suppression(pred, conf_thres, iou_thres)

    tile_coords = []
    class_ids = []

    for det in pred:
        if len(det):
            det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()
            for *xyxy, conf, cls_id in det:
                x0, y0, x1, y1 = map(int, xyxy)
                x0 += tile_pos[0]
                x1 += tile_pos[0]
                y0 += tile_pos[1]
                y1 += tile_pos[1]
                tile_coords.append([x0, y0, x1, y1])
                class_ids.append(int(cls_id))

    results_queue.put((tile_coords, class_ids))


def detect(source, weights, img_size=640, conf_thres=0.25, iou_thres=0.45, device='', trace=False):
    device = select_device(device)
    half = device.type != 'cpu'

    model = attempt_load(weights, map_location=device)
    stride = int(model.stride.max())
    img_size = check_img_size(img_size, s=stride)
    if trace:
        model = TracedModel(model, device, img_size)
    if half:
        model.half()

    source_img = source.copy()
    tiles, positions = split_image_into_tiles(source_img)

    threads = []
    results_queue = Queue()

    for i, tile in enumerate(tiles):
        thread = threading.Thread(
            target=detect_tile,
            args=(model, tile, positions[i], device, img_size, stride, half, conf_thres, iou_thres, results_queue)
        )
        thread.start()
        threads.append(thread)

    for t in threads:
        t.join()

    all_coords, all_classes = [], []
    while not results_queue.empty():
        coords, classes = results_queue.get()
        all_coords.extend(coords)
        all_classes.extend(classes)

    return source_img, all_coords, all_classes


# Main Execution
if __name__ == "__main__":
    path = './inference/images/horses.jpg'
    weights = './yolov7.pt'

    source = cv2.imread(path)
    source = cv2.resize(source, (4000, 1000), interpolation=cv2.INTER_LINEAR)

    original_img, tile_coordinates, class_ids = detect(
        source, weights, img_size=640, conf_thres=0.25, iou_thres=0.45, device=''
    )

    print("Detections:", len(tile_coordinates))

    for box, cls_id in zip(tile_coordinates, class_ids):
        label = f"{cls_id}"
        plot_one_box(box, original_img, label=label, color=[0, 255, 0], line_thickness=2)

    # Display results
    cv2.namedWindow("Detections", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("Detections", 1280, 1280)
    cv2.imshow("Detections", original_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
