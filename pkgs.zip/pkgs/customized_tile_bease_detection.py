import cv2
import torch
import time
import numpy as np
import os
import glob
from numpy import random
from models.experimental import attempt_load
from utils.general import check_img_size, non_max_suppression, scale_coords
from utils.plots import plot_one_box
from utils.torch_utils import select_device, time_synchronized, TracedModel
import concurrent.futures


def split_image_into_tiles(image, tile_size=640):
    tiles = []
    positions = []
    horizontal_overlap = 280
    vertical_overlap = 32
    h, w = image.shape[:2]
    for y in range(0, h - horizontal_overlap, tile_size - horizontal_overlap):
        for x in range(0, w - vertical_overlap, tile_size - vertical_overlap):
            tile = image[y:y + tile_size, x:x + tile_size]
            if tile.shape[0] == tile_size and tile.shape[1] == tile_size:
                tiles.append(tile)
                positions.append((x, y))
    return tiles, positions


def letterbox(img, new_shape=(640, 640), color=(114, 114, 114), auto=True, scaleFill=False, scaleup=True, stride=32):
    # Resize and pad image while meeting stride-multiple constraints
    shape = img.shape[:2]  # current shape [height, width]
    if isinstance(new_shape, int):
        new_shape = (new_shape, new_shape)

    # Scale ratio (new / old)
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    if not scaleup:  # only scale down, do not scale up (for better test mAP)
        r = min(r, 1.0)

    # Compute padding
    ratio = r, r  # width, height ratios
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]  # wh padding
    if auto:  # minimum rectangle
        dw, dh = np.mod(dw, stride), np.mod(dh, stride)  # wh padding
    elif scaleFill:  # stretch
        dw, dh = 0.0, 0.0
        new_unpad = (new_shape[1], new_shape[0])
        ratio = new_shape[1] / shape[1], new_shape[0] / shape[0]  # width, height ratios

    dw /= 2  # divide padding into 2 sides
    dh /= 2

    if shape[::-1] != new_unpad:  # resize
        img = cv2.resize(img, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    img = cv2.copyMakeBorder(img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)  # add border
    return img, ratio, (dw, dh)



def detect(source, weights, img_size=640, conf_thres=0.25, iou_thres=0.45, device='',
           save_conf=False, agnostic_nms=False, augment=False, update=False, trace=False):

    classes = None  # or specify your class indices like [0, 1] if needed
    device = select_device(device)
    half = device.type != 'cpu'  # half precision only supported on CUDA

    # Load model
    model = attempt_load(weights, map_location=device)
    stride = int(model.stride.max())
    img_size = check_img_size(img_size, s=stride)

    if trace:
        model = TracedModel(model, device, img_size)

    if half:
        model.half()

    names = model.module.names if hasattr(model, 'module') else model.names
    colors = [[random.randint(0, 255) for _ in range(3)] for _ in names]

    original_img = source.copy()
    tiles, positions = split_image_into_tiles(source)
    tile_coordinates = []
    class_ids = []


    for idx, tile in enumerate(tiles):
        tile_x_offset, tile_y_offset = positions[idx]
        im0 = tile
        # Preprocess
        img, ratio, (dw, dh) = letterbox(im0, new_shape=img_size, stride=stride)
        img = img[:, :, ::-1].transpose(2, 0, 1)  # BGR to RGB, to 3xHxW
        img = np.ascontiguousarray(img)

        img = torch.from_numpy(img).to(device)
        img = img.half() if half else img.float()
        img /= 255.0
        if img.ndimension() == 3:
            img = img.unsqueeze(0)

        # Inference
        t1 = time_synchronized()
        with torch.no_grad():
            pred = model(img, augment=augment)[0]
        t2 = time_synchronized()

        # NMS
        pred = non_max_suppression(pred, conf_thres, iou_thres, classes=classes, agnostic=agnostic_nms)
        t3 = time_synchronized()

        for i, det in enumerate(pred):
            if len(det):
                det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()
                for *xyxy, conf, cls_id in det:
                    x0, y0, x1, y1 = map(int, xyxy)
                    # Offset by tile position
                    x0 += tile_x_offset
                    x1 += tile_x_offset
                    y0 += tile_y_offset
                    y1 += tile_y_offset
                    tile_coordinates.append([x0, y0, x1, y1])
                    class_ids.append(int(cls_id))


            print(f'Done. ({(1E3 * (t2 - t1)):.1f}ms) Inference, ({(1E3 * (t3 - t2)):.1f}ms) NMS')

    return original_img, tile_coordinates, class_ids




path = './inference/images/horses.jpg'
weights ='./yolov7.pt'

if os.path.isdir(path):
    image_paths = glob.glob(os.path.join(path, '*.*'))
else:
    image_paths = [path]

source = cv2.imread(path)
source = cv2.resize(source, (4000, 1000), interpolation=cv2.INTER_LINEAR)


original_img, tile_coordinates, class_ids = detect(source, weights, img_size=640, conf_thres=0.25, iou_thres=0.45, device='',
           save_conf=False, agnostic_nms=False, augment=False, update=False, trace=False)

print("tile_coordinates",tile_coordinates) 
print("class_ids",class_ids)


for box, cls_id in zip(tile_coordinates, class_ids):
    label = f"{cls_id}"
    plot_one_box(box, original_img, label=label, color=[0, 255, 0], line_thickness=2)

# Save or display the image
cv2.namedWindow("Detections", cv2.WINDOW_NORMAL)  
cv2.resizeWindow("Detections", 1280, 1280)          
cv2.imshow("Detections", original_img)
cv2.waitKey(0)
cv2.destroyAllWindows()



# tiles, positions = split_image_into_tiles(source)
# print(len(tiles))

# for tile in tiles:
#     cv2.imshow("tile", tile)
#     print('tile shape', tile.shape)
#     cv2.waitKey(0)
#     cv2.destroyAllWindows()